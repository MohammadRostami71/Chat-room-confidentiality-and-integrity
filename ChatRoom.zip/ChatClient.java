
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import java.io.IOException;


public class ChatClient {
  public ChatClient(String username,String serverHost, int serverPort) 
                                                         throws IOException {

    Socket sock = new Socket(serverHost, serverPort);

    OutputStream out = sock.getOutputStream();

    new ReceiverThread(sock.getInputStream());

    // Send out username to the server.
    // Add Carriage Return (CR) first; receiver will have to strip CR
    //   CR is needed because receiver takes input one line at a time;
    //   so we need to put the username onto its own line.
    out.write((username+"\n").getBytes());
    out.flush();

    // Read in what the user types, and send it to the server.
    for(;;){
      int c = System.in.read();
      if(c == -1)    break;
      out.write(c);
      if(c == '\n')    out.flush();  // Make sure server gets everything.
    }
    out.close();
  }

  public static void main(String[] argv){
    String username = argv[0];
    String hostname = (argv.length<=1) ? "localhost" : argv[1];
    try{
      new ChatClient(username, hostname, ChatServer.portNum);
    }catch(IOException x){
      x.printStackTrace();
    }
  }

  class ReceiverThread extends Thread {
    // This is a thread that waits for bytes to arrive from the server.
    // When a whole line of text has arrived (or when the connection from 
    // the server is broken, it prints the line of incoming text.
    //
    // We put this in a separate thread so that the printing of incoming
    // text can proceed concurrently with the entry and sending of new
    // text.

    private InputStream in;

    ReceiverThread(InputStream inStream) {
      in = inStream;
      start();
    }

    public void run() {
      try{
	ByteArrayOutputStream baos;  // queues up stuff until carriage-return
	baos = new ByteArrayOutputStream();
	for(;;){
	  int c = in.read();
	  if(c == -1){
	    // connection from server was broken; output what we have
	    spew(baos);
	    break;
	  }
	  baos.write(c);
	  if(c == '\n')    spew(baos);  // got end of line; output what we have
	}
      }catch(IOException x){ }
    }

    private void spew(ByteArrayOutputStream baos) throws IOException {
      // Output the contents of baos; then reset (to empty) baos.
      byte[] message = baos.toByteArray();
      baos.reset();
      System.out.write(message);
    }
  }
}
